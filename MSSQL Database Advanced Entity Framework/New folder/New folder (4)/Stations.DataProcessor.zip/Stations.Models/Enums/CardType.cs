﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stations.Models.Enums
{
    public enum CardType
    {
        Pupil = 1,
        Student = 2,
        Elder = 3,
        Debilitated = 4,
        Normal = 0
    }
}
