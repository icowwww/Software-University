﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stations.Models.Enums
{
    public enum TripStatus
    {
        OnTime,
        Delayed,
        Early
    }
}
