namespace Stations.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-9TTUFDC\SQLEXPRESS;Database=Stations;Trusted_Connection=True";
	}
}