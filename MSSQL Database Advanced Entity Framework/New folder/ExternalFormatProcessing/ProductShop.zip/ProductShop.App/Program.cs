﻿using System;
using ProductShop.Data;

namespace ProductShop.App
{
    class Program
    {
        static void Main(string[] args)
        {
            //using (var s = new ProductShopContext())
            //{
            //    s.Database.EnsureDeleted();
            //    s.Database.EnsureCreated();
            //}

            //json part:
            //Console.WriteLine(JsonManager.SeedDatabase());
            //Console.WriteLine(JsonManager.GetProductsInRange());
            //Console.WriteLine(JsonManager.GetSuccessfullySold());
            //Console.WriteLine(JsonManager.GetCategoriesByProducts());


            //xml part:
            //Console.WriteLine(XmlManager.SeedDatabase());
            //Console.WriteLine(XmlManager.UsersAndProducts());
            //Console.WriteLine(XmlManager.CategoriesByProducts());
            //Console.WriteLine(XmlManager.ProductsInRange());
            //Console.WriteLine(XmlManager.SoldProducts());
        }
    }
}
