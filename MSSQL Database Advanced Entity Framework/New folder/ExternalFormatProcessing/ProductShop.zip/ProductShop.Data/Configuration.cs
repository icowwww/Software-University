﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            "Server=DESKTOP-9TTUFDC\\SQLEXPRESS;Database=ProductShop;Integrated Security = True;";
    }
}
