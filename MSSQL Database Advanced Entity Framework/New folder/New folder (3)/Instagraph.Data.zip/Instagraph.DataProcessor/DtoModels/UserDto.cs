﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Instagraph.DataProcessor.DtoModels
{
    public class UserDto
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string ProfilePicture { get; set; }
    }
}
