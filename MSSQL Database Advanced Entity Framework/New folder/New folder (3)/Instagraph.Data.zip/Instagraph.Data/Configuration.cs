﻿namespace Instagraph.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => "Server=DESKTOP-9TTUFDC\\SQLEXPRESS;Database=Instagraph;Integrated Security=True;";
    }
}
