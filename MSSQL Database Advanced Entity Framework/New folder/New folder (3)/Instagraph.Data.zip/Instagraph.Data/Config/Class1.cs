﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Instagraph.Data.Config
{
    class Class1
    {
    }
}
